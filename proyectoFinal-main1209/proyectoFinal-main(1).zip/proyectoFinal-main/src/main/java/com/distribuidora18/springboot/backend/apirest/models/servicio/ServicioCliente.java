package com.distribuidora18.springboot.backend.apirest.models.servicio;

import com.distribuidora18.springboot.backend.apirest.models.entity.Cliente;
import com.distribuidora18.springboot.backend.apirest.models.repository.RepoCliente;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Service
public class ServicioCliente {

    private RepoCliente repoCliente;

    public ServicioCliente(RepoCliente repoCliente) {
        this.repoCliente = repoCliente;
    }

    public List<Cliente> allClientes() {
        return repoCliente.findAll();
    }

    public Optional<Cliente> findById(Long id){


        return repoCliente.findById(id);
    }



    public String addCliente(Cliente cliente) {

        if (repoCliente.findById(cliente.getId_cliente()).isPresent()) {
            return "El Cliente ya se encuentra";
        } else {
            repoCliente.save(cliente);
            return "Cliente Guardado" + cliente.getId_cliente();
        }

    }

    // CAMBIAR LUEGO DE PROBAR A STRING
    public String deleteCliente(long id) {

        repoCliente.deleteById(id);
        return "Cliente = " + id + "Eliminado";


    }

    public void actualizarCliente(Cliente cliente){
        repoCliente.actualizarCliente(cliente.getNombre(),cliente.getApellido(),cliente.getId_cliente());
    }




}