package com.distribuidora18.springboot.backend.apirest.models.servicio;

import com.distribuidora18.springboot.backend.apirest.models.entity.CategoriaProducto;
import com.distribuidora18.springboot.backend.apirest.models.entity.Cliente;
import com.distribuidora18.springboot.backend.apirest.models.repository.RepoCategoriaProducto;
import com.distribuidora18.springboot.backend.apirest.models.repository.RepoCliente;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicioCategoriaProducto{

        private RepoCategoriaProducto repocategoria;

        public ServicioCategoriaProducto(RepoCategoriaProducto repocategoria) {
                this.repocategoria = repocategoria;
        }

        public List<CategoriaProducto> allCategoria() {
                return repocategoria.findAll();
        }

        public Optional<CategoriaProducto> findById(long id){


                return repocategoria.findById(id);
        }

        public String addCategoria(CategoriaProducto categoriaProducto) {

                if (repocategoria.findById(categoriaProducto.getId_categoria()).isPresent()) {
                        return "la categoria ya se encuentra";
                } else {
                        repocategoria.save(categoriaProducto);
                        return "Categoria Guardado" + categoriaProducto.getId_categoria();
                }

        }

        // CAMBIAR LUEGO DE PROBAR A STRING
        public String deleteCategoria(long id) {

                repocategoria.deleteById(id);
                return "Categoria = " + id + "Eliminado";


        }

/*
        public void actualizarDatosCategoria(CategoriaProducto categoriaActualizada){
                for(CategoriaProducto c: repocategoria){
                        if(){
                                e.setNombre(estudianteActualizado.getNombre());
                                e.setApellidos(estudianteActualizado.getApellidos());
                                e.setCurso(estudianteActualizado.getCurso());
                                e.setNota1(estudianteActualizado.getNota1());
                                e.setNota2(estudianteActualizado.getNota2());
                                e.setNota3(estudianteActualizado.getNota3());
                                return;
                        }
                }

        }

 */
        }
