package com.distribuidora18.springboot.backend.apirest.models.controlador;

public class ControladorVendedor {
}
