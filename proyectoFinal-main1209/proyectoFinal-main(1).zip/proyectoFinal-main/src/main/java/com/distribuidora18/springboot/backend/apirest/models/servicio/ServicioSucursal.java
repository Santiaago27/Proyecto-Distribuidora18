package com.distribuidora18.springboot.backend.apirest.models.servicio;

import com.distribuidora18.springboot.backend.apirest.models.entity.Sucursal;
import com.distribuidora18.springboot.backend.apirest.models.repository.RepoSucursal;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioSucursal {
    private RepoSucursal repoSucursal;
    public ServicioSucursal (RepoSucursal repoSucursal){this.repoSucursal=repoSucursal;}

    // Listar a todas las sucursales.
    public List<Sucursal> allSucursales(){return repoSucursal.findAll();}

    //Agregar Sucursal
    //Borrar el String y dejarlo void .

     public String addSucursal(Sucursal sucursal){

        if(repoSucursal.findById(sucursal.getId_sucursal()).isPresent()){
            return "Sucursal "+ sucursal.getId_sucursal() +"ya existe";
        }else {
                    repoSucursal.save(sucursal);
            return "Sucursal Guardada con Exito";
        }
     }
     //Borrar Sucursal

    public String deleteSucursal (Long id){
        repoSucursal.deleteById(id);
        return "Sucursal de id "+id+"Eliminado";
    }


}
