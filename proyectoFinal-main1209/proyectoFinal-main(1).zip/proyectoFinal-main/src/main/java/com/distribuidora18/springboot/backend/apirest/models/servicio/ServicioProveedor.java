package com.distribuidora18.springboot.backend.apirest.models.servicio;

import org.springframework.stereotype.Service;

@Service
public class ServicioProveedor {
}
